package snomedct

import org.neo4j.procedure.UserFunction
import org.neo4j.procedure.Description
import org.neo4j.procedure.Name

class ScratchPad{

    @UserFunction(name = "snomedct.scratch_jgp")
    fun scratch_jgp() : String
    {
        return "This is only a test.  The quick brown dog jumped over the lazy dog ... sir.";
    }

}