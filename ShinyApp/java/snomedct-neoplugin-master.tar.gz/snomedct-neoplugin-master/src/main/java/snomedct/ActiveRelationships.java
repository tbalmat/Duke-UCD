package snomedct;

import org.neo4j.graphdb.*;
import org.neo4j.graphdb.traversal.BranchState;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ActiveRelationships {

    // Mechanism for filtering relationships to only those with active='1' property

    // ================ ActiveRelationshipsIterator ==========================

    public static class ActiveRelationshipsIterator implements Iterator {
        private Iterator iterator;  /* original iterator */
        private Relationship nextRelationship;
        private boolean nextObjectSet = false;

        public ActiveRelationshipsIterator(Iterator iterator) {
            super();  // why needed?  what supertype constructor is being called?
            this.iterator = iterator;
            this.nextObjectSet = false;
        }

        public boolean hasNext() {
            if (this.nextObjectSet) {
                return true;
            } else {
                return this.setNextObject();
            }
        }

        public Object next() { // assumes hasNext() is true at this point
            if (!this.nextObjectSet) {
                if (!this.setNextObject()) {
                    throw new NoSuchElementException();
                }
            }
            this.nextObjectSet = false;
            return this.nextRelationship;
        }

        private boolean setNextObject() { // FILTER -- Require active='1' for any returned Relationship
            while (this.iterator.hasNext()) {  // a return statement ends this loop if an active relationship is found
                Relationship r = (Relationship) this.iterator.next(); /* The object must be a Relationship, since
                                                                         a-priori, this method was designed to only
                                                                         work with results from getRelationships() */
                if ( r.getProperty("active", "0").equals("1") ) {
                    this.nextRelationship = r;
                    this.nextObjectSet = true;
                    return true;
                }
            }
            return false; // No remaining active relationship found
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

    }

    // ================ ActiveRelationshipsIterable ==========================

    public static class ActiveRelationshipsIterable implements Iterable {

        private Iterable original_iterable;

        ActiveRelationshipsIterable(Iterable original) {
            this.original_iterable = original;
        }

        public Iterator iterator() {
            return new ActiveRelationshipsIterator(this.original_iterable.iterator());
        }

    } /* end class ActiveRelationshipsIterable */

    public static class ActiveRelationshipsPathExpander implements PathExpander {

        private RelationshipType edge_type;
        private Direction edge_direction;

        public ActiveRelationshipsPathExpander(RelationshipType edge_type,
                                               Direction edge_direction) {
            this.edge_type = edge_type; // eg: "ISA"
            this.edge_direction = edge_direction;
        }

        @Override
        public Iterable<Relationship> expand(Path path, BranchState objectBranchState) {
            return new ActiveRelationshipsIterable(
                    path.endNode().getRelationships(this.edge_type, this.edge_direction));
        }

        @Override
        public PathExpander<Object> reverse() {
            throw new UnsupportedOperationException();  // bi-directional traversal not supported
        }
    }

}
