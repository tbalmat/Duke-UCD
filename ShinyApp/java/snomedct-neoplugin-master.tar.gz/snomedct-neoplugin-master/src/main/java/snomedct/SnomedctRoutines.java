package snomedct;

import org.neo4j.graphdb.*;
import org.neo4j.graphdb.traversal.BranchState;
import org.neo4j.graphdb.traversal.Evaluators;
import org.neo4j.graphdb.traversal.TraversalDescription;
import org.neo4j.graphdb.traversal.Uniqueness;
import org.neo4j.logging.Log;
import org.neo4j.procedure.Context;
import org.neo4j.procedure.Mode;
import org.neo4j.procedure.Name;
import org.neo4j.procedure.Procedure;
import org.neo4j.procedure.UserFunction;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.stream.Stream;

import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * Created by Jay Pedersen, UNMC Pathology/Microbiology, December 20, 2017.
 */

public class SnomedctRoutines {
    //---------------------------------------------------------------------------------------
    //                            SNOMEDCT node specific processing
    //---------------------------------------------------------------------------------------

    @Context
    public GraphDatabaseService db;  // GraphDB reference

    @Context
    public Log log; // log file reference

    // Mechanism for creating a filtered version of an Iterable needed

    class ActiveRelationshipsIterator implements Iterator {

        private Iterator iterator;  /* original iterator */
        private Relationship nextRelationship;
        private boolean nextObjectSet = false;

        ActiveRelationshipsIterator(Iterator iterator) {
            super();  // why needed?  what supertype constructor is being called?
            this.iterator = iterator;
            this.nextObjectSet = false;
        }

        public boolean hasNext() {
            if (this.nextObjectSet) {
                return true;
            } else {
                return this.setNextObject();
            }
        }

        public Object next() { // assumes hasNext() is true at this point
            if (!this.nextObjectSet) {
                if (!this.setNextObject()) {
                    throw new NoSuchElementException();
                }
            }
            this.nextObjectSet = false;
            return this.nextRelationship;
        }

        private boolean setNextObject() { // FILTER -- Require active='1' for any returned Relationship
            while (this.iterator.hasNext()) {  // a return statement ends this loop if an active relationship is found
                Relationship r = (Relationship) this.iterator.next(); /* The object must be a Relationship, since
                                                                         a-priori, this method was designed to only
                                                                         work with results from getRelationships() */
                if ( r.getProperty("active", "0").equals("1") ) {
                    this.nextRelationship = r;
                    this.nextObjectSet = true;
                    return true;
                }
            }
            return false; // No remaining active relationship found
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

    } /* End class ActiveRelationshipsIterator */

    class ActiveRelationshipsIterable implements Iterable {

        private Iterable original_iterable;

        ActiveRelationshipsIterable(Iterable original) {
            this.original_iterable = original;
        }

        public Iterator iterator() {
            return new ActiveRelationshipsIterator(this.original_iterable.iterator());
        }
    } /* end class ActiveRelationshipsIterable */

    class ActiveRelationshipsPathExpander implements PathExpander {

        private RelationshipType edge_type;
        private Direction edge_direction;

        ActiveRelationshipsPathExpander(RelationshipType edge_type,
                                               Direction edge_direction) {
            this.edge_type = edge_type; // eg: "ISA"
            this.edge_direction = edge_direction;
        }

        @Override
        public Iterable<Relationship> expand(Path path, BranchState objectBranchState) {
            return new ActiveRelationshipsIterable(
                    path.endNode().getRelationships(this.edge_type, this.edge_direction));
        }

        @Override
        public PathExpander<Object> reverse() {
            throw new UnsupportedOperationException();  // bi-directional traversal not supported
        }
    }

    // nodes_reachable_by_outgoing_isa - return nodes reachable by outgoing ISA
    @Procedure(name = "snomedct.nodes_reachable_by_outgoing_isa", mode = Mode.READ)
    public Stream<PluginStructures.NodeResult> nodes_reachable_by_outgoing_isa(
            @Name("startNode") Node startNode,
            @Name(value="depth", defaultValue="-1") long d,
            @Name(value = "checkActiveFlag", defaultValue = "true") boolean checkActiveFlag)
    {
        // Start defining graph traversal -- td variable (traversal description)
        RelationshipType edge_type = RelationshipType.withName("ISA");
        Direction edge_direction = Direction.OUTGOING;
        TraversalDescription td =
                db.traversalDescription()
                        .depthFirst() // vs breadth first search
                        .uniqueness(Uniqueness.NODE_GLOBAL); // Dont process same node more than once
        if (!checkActiveFlag) {
            td = td.relationships(edge_type, edge_direction); // outgoing ISA edges
        } else {
            td = td.expand(new ActiveRelationshipsPathExpander(edge_type, edge_direction)); // ISA where active='1'
        }
        if (d >= 0) { td = td.evaluator(Evaluators.toDepth((int) d)); } // Add depth restriction as needed

        return td.traverse(startNode).nodes().stream().map(PluginStructures.NodeResult::new);  // Traverse and stream results to NEO4J
    }

    // SNOMED CT "subsumes" relationship, which ObjectConcept nodes have ISA paths to a given ObjectConcept
    @Procedure(name = "snomedct.node_subsumes", mode = Mode.READ)
    public Stream<PluginStructures.NodeResult> snomedct_node_subsumes(
            @Name("startNode") Node startNode,
            @Name(value = "checkActiveFlag", defaultValue = "true") boolean checkActiveFlag) {
        if (! startNode.hasLabel(Neo4jLabels.Labels.ObjectConcept)) {
            throw new IllegalArgumentException("Must be an ObjectConcept node");
        }
        // Start defining graph traversal -- td variable (traversal description)
        RelationshipType edge_type = RelationshipType.withName("ISA");
        Direction edge_direction = Direction.INCOMING;
        TraversalDescription td =
                db.traversalDescription()
                        .depthFirst() // vs breadth first search
                        .uniqueness(Uniqueness.NODE_GLOBAL); // Dont process same node more than once
        if (!checkActiveFlag) {
            td = td.relationships(edge_type, edge_direction); // all incoming ISA edges
        } else {
            td = td.expand(new ActiveRelationshipsPathExpander(edge_type, edge_direction)); // ISA where active='1'
        }

        return td.traverse(startNode).nodes().stream().map(PluginStructures.NodeResult::new); // Traverse, stream result to NEO4J
    }

    // SNOMED CT "subsumed by" relationship
    @Procedure(name = "snomedct.node_is_subsumed_by", mode = Mode.READ)
    public Stream<PluginStructures.NodeResult> snomedct_node_is_subsumed_by(
            @Name("startNode") Node startNode,
            @Name(value = "checkActiveFlag", defaultValue = "true") boolean checkActiveFlag) {
        if (! startNode.hasLabel(Neo4jLabels.Labels.ObjectConcept)) {
            throw new IllegalArgumentException("Must be an ObjectConcept node");
        }
        // Start defining graph traversal -- td variable (traversal description)
        RelationshipType edge_type = RelationshipType.withName("ISA");
        Direction edge_direction = Direction.OUTGOING;
        TraversalDescription td =
                db.traversalDescription()
                        .depthFirst() // vs breadth first search
                        .uniqueness(Uniqueness.NODE_GLOBAL); // Dont process same node more than once;
        if (!checkActiveFlag) {
            td = td.relationships(edge_type, edge_direction); // Traverse all outgoing ISA, regardless of active
        } else {
            td = td.expand(new ActiveRelationshipsPathExpander(edge_type, edge_direction)); // ISA where active='1'
        }

        return td.traverse(startNode).nodes().stream().map(PluginStructures.NodeResult::new); // Traverse, stream result to NEO4J
    }

    // Additions Oct 18, 2018 -- code_subsumes_codes

    // SNOMED CT "subsumes" relationship, which ObjectConcept nodes have ISA paths to a given ObjectConcept
    @UserFunction(name = "snomedct.node_subsumes_codes")
    public List<String> snomedct_node_subsumes_codes(
            @Name("startNode") Node startNode,
            @Name(value = "checkActiveFlag", defaultValue = "true") boolean checkActiveFlag) {
        if (! startNode.hasLabel(Neo4jLabels.Labels.ObjectConcept)) {
            throw new IllegalArgumentException("Must be an ObjectConcept node");
        }
        // Start defining graph traversal -- td variable (traversal description)
        RelationshipType edge_type = RelationshipType.withName("ISA");
        Direction edge_direction = Direction.INCOMING;
        TraversalDescription td =
                db.traversalDescription()
                        .depthFirst() // vs breadth first search
                        .uniqueness(Uniqueness.NODE_GLOBAL); // Dont process same node more than once
        if (!checkActiveFlag) {
            td = td.relationships(edge_type, edge_direction); // all incoming ISA edges
        } else {
            td = td.expand(new ActiveRelationships.ActiveRelationshipsPathExpander(edge_type, edge_direction)); // ISA where active='1'
        }

        // Iterable<Node> = td.traverse(startNode).nodes(); // Traverse, stream result to NEO4J

        // Traverse to find SNOMED CT metadata nodes ==> which we will refer to as 'b'
        List<String> allIds = new ArrayList<>(); // ids of all questions and answers
        for (Node node : td.traverse(startNode).nodes()) {
            allIds.add((String) node.getProperty("sctid")); // Track SNOMED CT ids of all matching nodes ==> metadata, also distinct values
        }

        return allIds;
    }

    // ObjectConcept "ISA" relationships, given concept node, return list of concept_code values from subsumed nodes
    @UserFunction(name = "snomedct.node_subsumed_by_codes")
    public List<String> snomedct_node_subsumed_by_codes(
            @Name("startNode") Node startNode,
            @Name(value = "checkActiveFlag", defaultValue = "true") boolean checkActiveFlag) {

        if (! startNode.hasLabel(Neo4jLabels.Labels.ObjectConcept)) {
            throw new IllegalArgumentException("Must be a ObjectConcept node");
        }
        // Start defining graph traversal -- td variable (traversal description)
        RelationshipType edge_type = RelationshipType.withName("ISA");
        Direction edge_direction = Direction.OUTGOING;
        TraversalDescription td =
                db.traversalDescription()
                        .depthFirst() // vs breadth first search
                        .uniqueness(Uniqueness.NODE_GLOBAL); // Dont process same node more than once

        if (!checkActiveFlag) {
            td = td.relationships(edge_type, edge_direction); // all incoming ISA edges
        } else {
            td = td.expand(new ActiveRelationships.ActiveRelationshipsPathExpander(edge_type, edge_direction)); // ISA where active='1'
        }

        // Traverse to find SNOMED CT metadata nodes ==> which we will refer to as 'b'
        List<String> allIds = new ArrayList<>(); // ids of all questions and answers
        for (Node node : td.traverse(startNode).nodes()) {
            allIds.add((String) node.getProperty("sctid")); // Track SNOMED CT ids of all matching nodes ==> metadata, also distinct values
        }

        return allIds;
    }

    // given concept_code, return list of codes it subsumes, uses ISA relation
    @UserFunction(name = "snomedct.code_subsumes_codes")
    public List<String> snomedct_code_subsumes_codes(
            @Name("sctid") String concept_code,
            @Name(value = "checkActiveFlag", defaultValue = "true") boolean checkActiveFlag)
            throws Exception // MultipleFoundException or exception if it finds zero
    {
        // match (a:Concept {concept_code:'<given-code>'})
        Node  startNode = db.findNode(Neo4jLabels.Labels.ObjectConcept, "sctid", concept_code);
        // return list of subsumed codes ... use snomedct_node_subsumes_nodes for this
        return snomedct_node_subsumes_codes(startNode, checkActiveFlag);
    }

    // given concept_code, return list of codes it is subsumed by, uses SUBSUMES relation
    @UserFunction(name = "snomedct.code_subsumed_by_codes")
    public List<String> snomedct_code_subsumed_by_codes(
            @Name("sctid") String concept_code,
            @Name(value = "checkActiveFlag", defaultValue = "true") boolean checkActiveFlag)
            throws Exception // MultipleFoundException or exception if it finds zero
    {
        // match (a:Concept {concept_code:'<given-code>'})
        Node  startNode = db.findNode(Neo4jLabels.Labels.ObjectConcept, "sctid", concept_code);
        // return list of subsumed codes ... use snomedct_node_subsumes_nodes for this
        return snomedct_node_subsumed_by_codes(startNode, checkActiveFlag);
    }

    // given concept_code, return list of codes it subsumes
    @UserFunction(name = "snomedct.code_list_subsumes_codes")
    public List<String> snomedct_code_list_subsumes_codes(
            @Name("snomedct_code_list") List<String> snomedct_code_list,
            @Name(value = "checkActiveFlag", defaultValue = "true") boolean checkActiveFlag)
            throws Exception // MultipleFoundException or exception if it finds zero
    {
        HashSet<String> subsumedCodesSet = new HashSet<>();
        for (String concept_code : snomedct_code_list) {
            // match (a:Concept {concept_code:'<given-code>'})
            Node startNode = db.findNode(Neo4jLabels.Labels.ObjectConcept, "sctid", concept_code);
            List<String> subsumedCodeList = snomedct_node_subsumes_codes(startNode, checkActiveFlag); // find subsumed codes
            subsumedCodesSet.addAll(subsumedCodeList); // Add to final result set
        }
        // return result
        return new ArrayList<>(subsumedCodesSet);
    }

}
