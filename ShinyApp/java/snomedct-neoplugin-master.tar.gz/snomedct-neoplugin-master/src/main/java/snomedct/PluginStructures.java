package snomedct;

import org.neo4j.graphdb.*;
import org.neo4j.logging.Log;
import org.neo4j.procedure.Context;
import org.neo4j.procedure.UserFunction;
import org.neo4j.procedure.Procedure;
import org.neo4j.procedure.Name;
import org.neo4j.procedure.Mode;
import org.neo4j.graphdb.traversal.Evaluators;
import org.neo4j.graphdb.traversal.Uniqueness;
import org.neo4j.graphdb.traversal.TraversalDescription;

import java.util.*;
import java.util.stream.Stream;

/**
 * Created by Jay Pedersen, UNMC Pathology/Microbiology, December 20, 2017.
 */
public class PluginStructures {

    // Attributes set by NEO4J's Dependency Injection for context variables: db, log

    @Context
    public GraphDatabaseService db;  // GraphDB reference

    @Context
    public Log log; // log file reference

    // Required wrapper of Node, needed by above procedures to stream Node results to NEO4J
    public static class NodeResult {
        public Node node;
        NodeResult(Node node) {
            this.node = node;
        }
    }

}
