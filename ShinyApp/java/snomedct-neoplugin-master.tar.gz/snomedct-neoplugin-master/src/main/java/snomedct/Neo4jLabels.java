package snomedct;

import org.neo4j.graphdb.Label;

/**
 * Created by Jay Pedersen, UNMC Pathology/Microbiology, December 20, 2017.
 */

public class Neo4jLabels {
    public enum Labels implements Label {
        ObjectConcept,
        NEC_META,
        NEC_Specimen,
        NEC_SynopticObservation,
        NEC_Patient
    }
}