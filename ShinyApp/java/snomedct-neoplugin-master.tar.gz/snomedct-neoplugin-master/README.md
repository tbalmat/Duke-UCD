# pathreports
Neo4j stored procedures to support NE CARES reports.

`call com.unmc.necares.nodes_reachable_by_outgoing_isa(node [,depth]) yield node [as <name>]`

```match (a:ObjectConcept {sctid:'19665009'})
call com.unmc.necares.nodes_reachable_by_outgoing_isa(a) yield node as reachable_nodes
return reachable_nodes

JUNIT tests, in src/test folder:
```
Currently has 3 tests:

The PLUGIN test and the REST API tests assume that the NEO4J
and the REST API are running on the local machine.

#1. PLUGIN test for getMetadata - getMetadata call, validates against large hard-coded string of results

                  which you should get from the de-identified database

#2. REST API test for getMetadata -- (a) uses endpoint "http://localhost:8083/reports/getMetaDataAPOC/",

                     (b) also calls getMetadata method from plugin

                         match (a:NEC_META {id:'RootMetaNode'}) return necares.get_metadata_tree(a) as outputJSON

                     (c) compares the array results from both

                     (d) checks specifically for "CASEDIAG_75" metadata node, to ensure it exists

                         as a sanity check.

#3. Plugin test for "days between dates" plugin method

       (a) Has leap year test to make sure Feb 29 is counted.
   ```